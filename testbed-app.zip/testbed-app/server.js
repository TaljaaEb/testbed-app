const express = require('express');
const http = require('http');
const { Server } = require("socket.io");
const { Client } = require('ssh2');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id}`);

    const sshConnections = new Map();

    socket.on('connect-ssh', (details) => {
        const { target, host, port, username, password } = details;
        const conn = new Client();
        
        // IMPORTANT: In a real-world application, use SSH keys and environment variables.
        // Avoid sending passwords from the client-side like this. This is for conceptual purposes.
        const sshConfig = {
            host: host,
            port: port || 22,
            username: username,
            password: password 
            // For key-based authentication (recommended):
            // privateKey: require('fs').readFileSync('/path/to/your/private/key')
        };

        conn.on('ready', () => {
            console.log(`SSH connection ready for ${target}`);
            socket.emit(`${target}-status`, 'SSH connection successful.');

            conn.shell((err, stream) => {
                if (err) {
                    socket.emit(`${target}-data`, `\r\nError starting shell: ${err.message}\r\n`);
                    return;
                }

                sshConnections.set(target, { conn, stream });

                stream.on('close', () => {
                    console.log(`SSH stream closed for ${target}`);
                    socket.emit(`${target}-status`, 'SSH connection closed.');
                    sshConnections.delete(target);
                }).on('data', (data) => {
                    socket.emit(`${target}-data`, data.toString('utf-8'));
                });

                // Handle initial resize from client
                socket.on(`${target}-resize`, ({ rows, cols }) => {
                    stream.setWindow(rows, cols);
                });
            });
        }).on('error', (err) => {
            console.error(`SSH connection error for ${target}: ${err.message}`);
            socket.emit(`${target}-status`, `Error: ${err.message}`);
        }).connect(sshConfig);
    });

    socket.on('data-to-server', ({ target, data }) => {
        const ssh = sshConnections.get(target);
        if (ssh && ssh.stream) {
            ssh.stream.write(data);
        }
    });

    socket.on('disconnect', () => {
        console.log(`Socket disconnected: ${socket.id}`);
        sshConnections.forEach(({ conn }, target) => {
            console.log(`Closing SSH connection for ${target} due to socket disconnect.`);
            conn.end();
        });
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server listening on http://localhost:${PORT}`);
});