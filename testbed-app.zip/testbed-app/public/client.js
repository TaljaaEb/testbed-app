document.addEventListener('DOMContentLoaded', function () {
    const socket = io();

    // --- Terminal Setup Function ---
    function setupTerminal(target) {
        const terminalContainer = document.getElementById(`${target}-terminal`);
        const term = new Terminal({
            cursorBlink: true,
            theme: {
                background: '#000000',
                foreground: '#ffffff'
            }
        });
        term.open(terminalContainer);

        // Handle data from server -> terminal
        socket.on(`${target}-data`, (data) => {
            term.write(data);
        });
        
        // Handle status messages
        socket.on(`${target}-status`, (message) => {
            term.write(`\r\n\x1b[33m[STATUS]\x1b[0m ${message}\r\n`);
        });

        // Handle data from terminal -> server
        term.onData(data => {
            socket.emit('data-to-server', { target, data });
        });

        // Connect button logic
        document.getElementById(`${target}-connect-btn`).addEventListener('click', () => {
            const host = document.getElementById(`${target}-ip`).value;
            const username = document.getElementById(`${target}-user`).value;
            const password = document.getElementById(`${target}-pass`).value;
            
            document.getElementById(`${target}-login-form`).style.display = 'none';
            term.write(`\x1b[32mConnecting to ${host}...\x1b[0m\r\n`);
            
            socket.emit('connect-ssh', { target, host, port: 22, username, password });
        });
    }

    setupTerminal('host');
    setupTerminal('localhost');

    // --- Mini-browser Logic ---
    const urlInput = document.getElementById('url-input');
    const goBtn = document.getElementById('go-btn');
    const iframe = document.getElementById('mini-browser');

    function loadUrl() {
        let url = urlInput.value;
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'http://' + url;
        }
        iframe.src = url;
    }

    goBtn.addEventListener('click', loadUrl);
    urlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            loadUrl();
        }
    });

    // --- Panel Resizing Logic ---
    const resizers = document.querySelectorAll('.resizer');
    let isResizing = false;

    resizers.forEach(resizer => {
        resizer.addEventListener('mousedown', (e) => {
            isResizing = true;
            const targetPanel = document.getElementById(resizer.dataset.target);
            const nextPanel = resizer.nextElementSibling;
            
            // Disable pointer events on iframe to prevent capturing mouse events
            iframe.style.pointerEvents = 'none';

            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', () => {
                isResizing = false;
                document.removeEventListener('mousemove', handleMouseMove);
                // Re-enable pointer events on iframe
                iframe.style.pointerEvents = 'auto';
            });

            function handleMouseMove(e) {
                if (!isResizing) return;
                const container = document.querySelector('.container');
                const containerWidth = container.offsetWidth;
                
                const targetNewWidth = e.clientX - targetPanel.getBoundingClientRect().left;
                const nextPanelNewWidth = nextPanel.getBoundingClientRect().right - e.clientX;

                const targetNewFlex = targetNewWidth / containerWidth;
                const nextPanelNewFlex = nextPanelNewWidth / containerWidth;
                const otherPanelFlex = 1 - targetNewFlex - nextPanelNewFlex;

                if (resizer.dataset.target === 'left-panel') {
                    targetPanel.style.flexBasis = `${targetNewWidth}px`;
                    nextPanel.style.flexBasis = `${containerWidth - targetNewWidth - document.getElementById('right-panel').offsetWidth}px`;
                } else { // middle-panel resizer
                    const leftPanel = document.getElementById('left-panel');
                    targetPanel.style.flexBasis = `${e.clientX - leftPanel.getBoundingClientRect().right - resizer.offsetWidth}px`;
                    nextPanel.style.flexBasis = `${container.getBoundingClientRect().right - e.clientX}px`;
                }
            }
        });
    });
});